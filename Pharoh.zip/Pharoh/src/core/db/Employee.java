package core.db;

public class Employee {
}
