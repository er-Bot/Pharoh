create trigger EMPL_ID_TRIG
    before insert
    on EMPLOYEE
    for each row
begin  
   if inserting then 
      if :NEW."EMPL_ID" is null then 
         select EMPL_SEQ.nextval into :NEW."EMPL_ID" from dual; 
      end if; 
   end if; 
end;
/

