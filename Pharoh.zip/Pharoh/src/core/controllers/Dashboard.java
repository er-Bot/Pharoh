package core.controllers;

public class Dashboard {
    public static Integer totalDueCtr;
    public static Double totalDueAmount;
    public static Integer todaySellCtr;
    public static Double todaysTotalSell;
    public static Integer todaysRentalCtr;
    public static Double todayTotalRental;
    public static Double todaysTotalDue;
    public static Integer stockOut;
}
