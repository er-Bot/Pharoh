package core.db;

public class Client {

    public Client(int clt_id, String clt_fname, String clt_lname, String clt_sex, String clt_address, String clt_tel, String clt_order_doct, String clt_order_num) {

    }
}
