create trigger PHAR_ID_TRIGGER
    before insert
    on PHARMACY
    for each row
begin  
   if inserting then 
      if :NEW."PHAR_ID" is null then 
         select PHARMACIE_SEQ.nextval into :NEW."PHAR_ID" from dual; 
      end if; 
   end if; 
end;
/

