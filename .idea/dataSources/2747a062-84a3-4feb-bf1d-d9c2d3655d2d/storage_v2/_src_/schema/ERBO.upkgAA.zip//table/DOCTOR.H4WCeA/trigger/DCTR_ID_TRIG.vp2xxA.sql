create trigger DCTR_ID_TRIG
    before insert
    on DOCTOR
    for each row
begin  
   if inserting then 
      if :NEW."DOCT_ID" is null then 
         select DOCT_SEQ.nextval into :NEW."DOCT_ID" from dual; 
      end if; 
   end if; 
end;
/

