create trigger CCMD_ID_TRIG
    before insert
    on CLIENT_COMMAND
    for each row
begin  
   if inserting then 
      if :NEW."CCMD_ID" is null then 
         select CCMD_SEQ.nextval into :NEW."CCMD_ID" from dual; 
      end if; 
   end if; 
end;
/

