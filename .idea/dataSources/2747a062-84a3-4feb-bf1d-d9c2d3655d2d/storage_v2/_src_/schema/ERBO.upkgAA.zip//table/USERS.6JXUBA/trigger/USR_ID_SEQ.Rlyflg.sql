create trigger USR_ID_SEQ
    before insert
    on USERS
    for each row
begin  
   if inserting then 
      if :NEW."USR_ID" is null then 
         select USERS_SEQ.nextval into :NEW."USR_ID" from dual; 
      end if; 
   end if; 
end;
/

