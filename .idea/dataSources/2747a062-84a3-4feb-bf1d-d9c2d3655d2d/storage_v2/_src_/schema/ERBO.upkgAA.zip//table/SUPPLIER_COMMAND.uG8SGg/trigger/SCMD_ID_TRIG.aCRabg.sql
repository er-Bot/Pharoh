create trigger SCMD_ID_TRIG
    before insert
    on SUPPLIER_COMMAND
    for each row
begin  
   if inserting then 
      if :NEW."SCMD_ID" is null then 
         select SCMD_SEQ.nextval into :NEW."SCMD_ID" from dual; 
      end if; 
   end if; 
end;
/

