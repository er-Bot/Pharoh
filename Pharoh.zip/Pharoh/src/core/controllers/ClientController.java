package core.controllers;

import core.db.Client;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class ClientController {
    public static ObservableList<Client> clientsList;
    public static ArrayList<String> clientNames;
}
