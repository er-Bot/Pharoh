package core.controllers;

import java.util.ArrayList;

public class PurchaseController {
    public static ArrayList<String> inventoryMedicine;
    public static ArrayList<Integer> medicineIDForRent;
}
