create trigger SCL_ID_TRIG
    before insert
    on SUPPLIER_COMMAND_LINE
    for each row
begin  
   if inserting then 
      if :NEW."SCL_ID" is null then 
         select SCL_SEQ.nextval into :NEW."SCL_ID" from dual; 
      end if; 
   end if; 
end;
/

