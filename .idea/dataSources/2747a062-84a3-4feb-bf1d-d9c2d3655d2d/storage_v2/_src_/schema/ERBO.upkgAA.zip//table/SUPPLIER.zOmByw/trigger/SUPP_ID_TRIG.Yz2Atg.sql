create trigger SUPP_ID_TRIG
    before insert
    on SUPPLIER
    for each row
begin  
   if inserting then 
      if :NEW."SUPL_ID" is null then 
         select SUPPLIER_SEQ.nextval into :NEW."SUPL_ID" from dual; 
      end if; 
   end if; 
end;
/

