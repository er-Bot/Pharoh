package core.db;

import java.sql.Date;

public class Medicine {

    public Medicine(int medi_id, String medi_name, Date medi_expire_date, double medi_pu, double medi_stock_ste, String medi_desc, String medi_dci, String medi_form, double medi_dose) {
    }
}
