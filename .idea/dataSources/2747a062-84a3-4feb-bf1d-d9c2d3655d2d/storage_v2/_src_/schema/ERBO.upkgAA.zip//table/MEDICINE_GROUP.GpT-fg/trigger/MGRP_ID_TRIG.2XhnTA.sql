create trigger MGRP_ID_TRIG
    before insert
    on MEDICINE_GROUP
    for each row
begin  
   if inserting then 
      if :NEW."MGRP_ID" is null then 
         select MGRP_SEQ.nextval into :NEW."MGRP_ID" from dual; 
      end if; 
   end if; 
end;
/

