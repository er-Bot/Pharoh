create trigger CLT_ID_TRIG
    before insert
    on CLIENT
    for each row
begin  
   if inserting then 
      if :NEW."CLT_ID" is null then 
         select CLIENT_SEQ.nextval into :NEW."CLT_ID" from dual; 
      end if; 
   end if; 
end;
/

