package core.controllers;

import java.util.ArrayList;

public class SellsController {
    public static ArrayList<String> clientIDName;
    public static ArrayList<Integer> clientID;
    public static ArrayList<String> inventoryMedicine;
    public static ArrayList<Integer> medicineIDForSale;
}
